import React from "react";
import { RegisterRow } from "./_components/register-row";

export default function RegisterPage() {
  return <RegisterRow />;
}
