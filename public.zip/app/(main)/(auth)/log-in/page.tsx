import React from "react";
import { LoginRow } from "./_components/login-row";

export default function LoginPage() {
  return <LoginRow />;
}
